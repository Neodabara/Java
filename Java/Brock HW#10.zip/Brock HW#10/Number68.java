
public class Number68 {
    public static void main(String [] args){
        
        double [][] finale = new double [2][3];
        finale[0][0]= 12.34;
        finale[0][1]= 23.45;
        finale[0][2]= 34.56;
        finale[1][0]= 45.67;
        finale[1][1]= 56.78;
        finale[1][2]= 67.89;
        
        System.out.println("The number of rows in the finale array is: " + finale.length);

    }
}
