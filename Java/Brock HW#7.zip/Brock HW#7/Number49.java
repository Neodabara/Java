/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw.problems;



public class Number49 {
    public static void main(String[] args){
        double millimeter = 25.4;
        
        double a = 2 * millimeter;
        double b = 5 * millimeter;
        double c = 10 * millimeter;
        
        System.out.print("2 inches is equal to " + a + " millimeters");
        System.out.println("5 inchess is equal to " + b + " millimeters");
        System.out.println("10 inches is equal to " + c + " millimeters");
    }
}
