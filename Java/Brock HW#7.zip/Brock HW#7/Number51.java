/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw.problems;

import java.util.Scanner;

public class Number51 {
    public static void main(String[] args){
        Scanner scan = new Scanner( System.in );
        
        System.out.print("Enter a name >");
        String name = scan.nextLine( );
        
        System.out.println("www." +name + ".com");
}
}
